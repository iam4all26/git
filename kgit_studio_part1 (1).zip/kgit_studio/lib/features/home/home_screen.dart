import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/theme/app_colors.dart';
import '../../shared/widgets/coming_soon_screen.dart';
import '../projects/new_local_project_sheet.dart';
import '../projects/project.dart';
import '../projects/project_providers.dart';
import '../projects/project_repository.dart';
import '../projects/project_tile.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _openTab(int i) => ref.read(tabIndexProvider.notifier).state = i;

  void _showNotifications() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) {
        final k = ctx.k;
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.notifications_none_rounded, size: 40, color: k.muted),
              const SizedBox(height: 10),
              Text('No notifications',
                  style: TextStyle(
                      color: k.text, fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(
                'Build results and sync alerts will appear here once GitHub is connected.',
                textAlign: TextAlign.center,
                style: TextStyle(color: k.muted, fontSize: 13.5, height: 1.4),
              ),
            ],
          ),
        );
      },
    );
  }

  void _openRepositories() {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => const ComingSoonScreen(
        title: 'Repositories',
        icon: Icons.storage_rounded,
        part: 'Part 3',
        showBack: true,
        willInclude: [
          'Connect GitHub with a Personal Access Token',
          'Browse, search, filter and refresh your repositories',
          'Create repositories and view branches, commits and pull requests',
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    final projects = ref.watch(allProjectsProvider);
    final stats = ref.watch(dashboardStatsProvider);

    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        color: AppColors.purple,
        onRefresh: () async {
          refreshProjectData(ref);
          await ref.read(allProjectsProvider.future);
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
          children: [
            _Header(onAvatar: () => _openTab(4), onBell: _showNotifications),
            const SizedBox(height: 16),
            _SearchField(
              controller: _search,
              onChanged: (v) => setState(() => _query = v.trim()),
              onClear: () => setState(() {
                _search.clear();
                _query = '';
              }),
            ),
            const SizedBox(height: 14),
            _StatsGrid(
              stats: stats,
              onProjects: () => _openTab(1),
              onRepositories: _openRepositories,
              onBuilds: () => _openTab(2),
              onArtifacts: () => _openTab(3),
              onRetry: () => ref.invalidate(dashboardStatsProvider),
            ),
            const SizedBox(height: 12),
            _StatusStrip(stats: stats),
            const SizedBox(height: 22),
            Row(
              children: [
                Text('Recent Projects',
                    style: TextStyle(
                        color: k.text,
                        fontSize: 17,
                        fontWeight: FontWeight.w800)),
                const Spacer(),
                TextButton(
                  onPressed: () => _openTab(1),
                  style: TextButton.styleFrom(
                      minimumSize: const Size(48, 40),
                      padding: const EdgeInsets.symmetric(horizontal: 8)),
                  child: const Text('See all'),
                ),
              ],
            ),
            const SizedBox(height: 6),
            projects.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 36),
                child: Center(
                    child: CircularProgressIndicator(color: AppColors.purple)),
              ),
              error: (e, _) => _MessageCard(
                icon: Icons.error_outline_rounded,
                color: AppColors.danger,
                title: 'Could not load projects',
                message: 'Pull down to try again, or tap Retry.',
                actionLabel: 'Retry',
                onAction: () => ref.invalidate(allProjectsProvider),
              ),
              data: (list) => _RecentProjects(
                all: list,
                query: _query,
                onCreate: () => showNewLocalProjectSheet(context),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- header

class _Header extends StatelessWidget {
  const _Header({required this.onAvatar, required this.onBell});
  final VoidCallback onAvatar;
  final VoidCallback onBell;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Row(
      children: [
        InkWell(
          customBorder: const CircleBorder(),
          onTap: onAvatar,
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: k.surfaceHigh,
              border: Border.all(color: AppColors.purple.withAlpha(140), width: 1.5),
            ),
            child: Icon(Icons.person_outline_rounded, color: k.muted),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text('K-Git Studio',
              style: TextStyle(
                  color: k.text, fontSize: 21, fontWeight: FontWeight.w800)),
        ),
        IconButton(
          tooltip: 'Notifications',
          onPressed: onBell,
          icon: Icon(Icons.notifications_none_rounded, color: k.text, size: 26),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------- search

class _SearchField extends StatelessWidget {
  const _SearchField({
    required this.controller,
    required this.onChanged,
    required this.onClear,
  });
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return TextField(
      controller: controller,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
      style: TextStyle(color: k.text, fontSize: 14.5),
      decoration: InputDecoration(
        hintText: 'Search projects, repositories...',
        prefixIcon: Icon(Icons.search_rounded, color: k.muted),
        suffixIcon: controller.text.isEmpty
            ? null
            : IconButton(
                tooltip: 'Clear',
                icon: Icon(Icons.close_rounded, color: k.muted),
                onPressed: onClear,
              ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12),
      ),
    );
  }
}

// ---------------------------------------------------------------- stats

class _StatsGrid extends StatelessWidget {
  const _StatsGrid({
    required this.stats,
    required this.onProjects,
    required this.onRepositories,
    required this.onBuilds,
    required this.onArtifacts,
    required this.onRetry,
  });

  final AsyncValue<DashboardStats> stats;
  final VoidCallback onProjects;
  final VoidCallback onRepositories;
  final VoidCallback onBuilds;
  final VoidCallback onArtifacts;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final s = stats.valueOrNull;
    String value(int? n) => stats.hasError ? '!' : (n == null ? '-' : '$n');

    final cards = [
      _StatCard(
        label: 'My Projects',
        value: value(s?.projects),
        icon: Icons.folder_open_rounded,
        color: AppColors.info,
        onTap: onProjects,
      ),
      _StatCard(
        label: 'Repositories',
        value: value(s?.repositories),
        icon: Icons.storage_rounded,
        color: AppColors.success,
        onTap: onRepositories,
      ),
      _StatCard(
        label: 'Builds',
        value: value(s?.builds),
        icon: Icons.construction_rounded,
        color: AppColors.purpleSoft,
        onTap: onBuilds,
      ),
      _StatCard(
        label: 'Artifacts',
        value: value(s?.artifacts),
        icon: Icons.inventory_2_outlined,
        color: AppColors.gold,
        onTap: onArtifacts,
      ),
    ];

    return Column(
      children: [
        Row(children: [
          Expanded(child: cards[0]),
          const SizedBox(width: 10),
          Expanded(child: cards[1]),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: cards[2]),
          const SizedBox(width: 10),
          Expanded(child: cards[3]),
        ]),
        if (stats.hasError)
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
                onPressed: onRetry, child: const Text('Could not load counts. Retry')),
          ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          height: 78,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color.withAlpha(k.isDark ? 70 : 40), k.surface],
            ),
            border: Border.all(color: color.withAlpha(110)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withAlpha(50),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: color.withAlpha(120)),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: k.muted, fontSize: 12.5)),
                    const SizedBox(height: 2),
                    Text(value,
                        style: TextStyle(
                            color: k.text,
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            height: 1.1)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- status strip

/// Real state only (spec 5.2): GitHub connection and unsynchronized projects.
class _StatusStrip extends StatelessWidget {
  const _StatusStrip({required this.stats});
  final AsyncValue<DashboardStats> stats;

  @override
  Widget build(BuildContext context) {
    final pending = stats.valueOrNull?.pendingSync ?? 0;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        const _Pill(
          icon: Icons.link_off_rounded,
          text: 'GitHub not connected',
          color: AppColors.warning,
        ),
        if (pending > 0)
          _Pill(
            icon: Icons.sync_problem_rounded,
            text: '$pending project${pending == 1 ? '' : 's'} need sync',
            color: AppColors.gold,
          ),
      ],
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.text, required this.color});
  final IconData icon;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(100)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- recent projects

class _RecentProjects extends StatelessWidget {
  const _RecentProjects({
    required this.all,
    required this.query,
    required this.onCreate,
  });

  final List<Project> all;
  final String query;
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    if (all.isEmpty) {
      return _MessageCard(
        icon: Icons.folder_open_rounded,
        color: AppColors.purpleSoft,
        title: 'No projects yet',
        message:
            'Create a project on this phone, then paste code from any AI assistant and build it in the cloud.',
        actionLabel: 'New local project',
        onAction: onCreate,
      );
    }

    final q = query.toLowerCase();
    final shown = q.isEmpty
        ? all.take(4).toList()
        : all
            .where((p) =>
                p.name.toLowerCase().contains(q) ||
                p.slug.contains(q) ||
                (p.repositoryName ?? '').toLowerCase().contains(q))
            .toList();

    if (shown.isEmpty) {
      return _MessageCard(
        icon: Icons.search_off_rounded,
        color: context.k.muted,
        title: 'No matches',
        message: 'No project matches "$query".',
      );
    }

    return Column(
      children: [
        for (final p in shown)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ProjectTile(
              project: p,
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('The project workspace is built in Part 4.')),
              ),
            ),
          ),
        const SizedBox(height: 4),
        OutlinedButton.icon(
          onPressed: onCreate,
          icon: const Icon(Icons.add_rounded),
          label: const Text('New local project'),
        ),
      ],
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: k.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: k.border),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 38),
          const SizedBox(height: 10),
          Text(title,
              style: TextStyle(
                  color: k.text, fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(message,
              textAlign: TextAlign.center,
              style: TextStyle(color: k.muted, fontSize: 13.5, height: 1.4)),
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 16),
            FilledButton(onPressed: onAction, child: Text(actionLabel!)),
          ],
        ],
      ),
    );
  }
}
