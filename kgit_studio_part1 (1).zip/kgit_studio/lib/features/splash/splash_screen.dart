import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/shell/app_shell.dart';
import '../../app/theme/app_colors.dart';
import '../../features/projects/project_providers.dart';
import '../../shared/widgets/k_logo.dart';

/// Mockup 1. Always uses the dark flagship look, whatever theme is saved.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _progress;
  String? _error;

  static const _white = Color(0xFFF3F4FF);
  static const _muted = Color(0xFF9AA0D6);

  @override
  void initState() {
    super.initState();
    _progress = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1900));
    _boot();
  }

  @override
  void dispose() {
    _progress.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    await ref.read(appDatabaseProvider).database;
    await ref.read(themeModeProvider.notifier).load();
  }

  Future<void> _boot() async {
    setState(() => _error = null);
    _progress.forward(from: 0);
    try {
      await Future.wait([
        _init(),
        Future<void>.delayed(const Duration(milliseconds: 2000)),
      ]);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => const AppShell(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ));
    } catch (_) {
      if (!mounted) return;
      _progress.stop();
      setState(() => _error =
          'K-Git Studio could not open its local storage. Free up some space on your phone and try again.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050716),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const CustomPaint(painter: _SkyPainter()),
          SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 5),
                const KLogo(size: 116),
                const SizedBox(height: 26),
                const Text(
                  'K-Git Studio',
                  style: TextStyle(
                      color: _white,
                      fontSize: 40,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5),
                ),
                const SizedBox(height: 10),
                Text(
                  'Build • Code • Manage • Deploy',
                  style: TextStyle(
                      color: _white.withAlpha(225),
                      fontSize: 15,
                      letterSpacing: 0.3),
                ),
                const SizedBox(height: 34),
                const Text(
                  'Your Complete Mobile\nDevelopment Studio',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: _muted, fontSize: 15, height: 1.45),
                ),
                const Spacer(flex: 6),
                if (_error == null) _ProgressBar(animation: _progress) else _ErrorBlock(message: _error!, onRetry: _boot),
                const SizedBox(height: 26),
                const Text(
                  'Powered by GitHub\nBuilt for Creators',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: _muted, fontSize: 12, height: 1.5),
                ),
                const SizedBox(height: 18),
                Container(
                  width: 120,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(90),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressBar extends StatelessWidget {
  const _ProgressBar({required this.animation});
  final Animation<double> animation;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 210,
      height: 5,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(5),
        child: Stack(
          children: [
            Container(color: Colors.white.withAlpha(30)),
            AnimatedBuilder(
              animation: animation,
              builder: (_, __) => FractionallySizedBox(
                widthFactor: Curves.easeInOut.transform(animation.value),
                alignment: Alignment.centerLeft,
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.purpleSoft, AppColors.purple],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBlock extends StatelessWidget {
  const _ErrorBlock({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          Text(message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Color(0xFFFFB4B4), fontSize: 13.5, height: 1.4)),
          const SizedBox(height: 12),
          SizedBox(
            width: 160,
            child: FilledButton(onPressed: onRetry, child: const Text('Try again')),
          ),
        ],
      ),
    );
  }
}

class _SkyPainter extends CustomPainter {
  const _SkyPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF040514), Color(0xFF0A0B2E), Color(0xFF1B1356)],
        ).createShader(rect),
    );

    // Soft purple glow behind the logo.
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          colors: const [Color(0x557351FF), Color(0x007351FF)],
        ).createShader(Rect.fromCircle(
            center: Offset(size.width * 0.5, size.height * 0.3),
            radius: size.width * 0.85)),
    );

    // Stars (fixed seed so the sky is stable).
    final rnd = math.Random(7);
    final star = Paint();
    for (var i = 0; i < 120; i++) {
      final x = rnd.nextDouble() * size.width;
      final y = rnd.nextDouble() * size.height * 0.72;
      final r = rnd.nextDouble() * 1.1 + 0.2;
      star.color = Colors.white.withAlpha(60 + rnd.nextInt(170));
      canvas.drawCircle(Offset(x, y), r, star);
    }

    // Mountain silhouette.
    final w = size.width;
    final h = size.height;
    final far = Path()
      ..moveTo(0, h * 0.80)
      ..lineTo(w * 0.15, h * 0.70)
      ..lineTo(w * 0.30, h * 0.78)
      ..lineTo(w * 0.48, h * 0.66)
      ..lineTo(w * 0.66, h * 0.79)
      ..lineTo(w * 0.84, h * 0.70)
      ..lineTo(w, h * 0.78)
      ..lineTo(w, h)
      ..lineTo(0, h)
      ..close();
    canvas.drawPath(
      far,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF2E1F86), Color(0xFF0A0A26)],
        ).createShader(rect),
    );

    final near = Path()
      ..moveTo(0, h * 0.86)
      ..lineTo(w * 0.22, h * 0.78)
      ..lineTo(w * 0.40, h * 0.86)
      ..lineTo(w * 0.62, h * 0.76)
      ..lineTo(w * 0.80, h * 0.85)
      ..lineTo(w, h * 0.80)
      ..lineTo(w, h)
      ..lineTo(0, h)
      ..close();
    canvas.drawPath(
      near,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1A1058), Color(0xFF050716)],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
