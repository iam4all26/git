import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';

/// Frameworks the app supports at launch (spec 6.3).
enum ProjectFramework {
  flutter('flutter', 'Flutter', Icons.flutter_dash, AppColors.info),
  android('android', 'Android', Icons.android, AppColors.success),
  web('web', 'Web / PWA', Icons.language, AppColors.purpleSoft),
  repository('repository', 'Repository', Icons.folder_open_rounded,
      AppColors.gold);

  const ProjectFramework(this.id, this.label, this.icon, this.color);
  final String id;
  final String label;
  final IconData icon;
  final Color color;

  static ProjectFramework fromId(String? id) => ProjectFramework.values
      .firstWhere((f) => f.id == id, orElse: () => ProjectFramework.repository);
}

/// Synchronization states (spec 16.1).
class SyncState {
  SyncState._();
  static const localOnly = 'local_only';
  static const linked = 'linked';
  static const upToDate = 'up_to_date';
  static const localChangesPending = 'local_changes_pending';
  static const remoteChangesDetected = 'remote_changes_detected';
  static const syncing = 'sync_in_progress';
  static const conflict = 'conflict';
  static const failed = 'sync_failed';
  static const offline = 'offline';

  /// States that need the user's attention on the dashboard.
  static const needsAttention = [localChangesPending, conflict, failed];

  static String label(String s) {
    switch (s) {
      case localOnly:
        return 'Local only';
      case linked:
        return 'Linked';
      case upToDate:
        return 'Up to date';
      case localChangesPending:
        return 'Local changes pending';
      case remoteChangesDetected:
        return 'Remote changes';
      case syncing:
        return 'Syncing';
      case conflict:
        return 'Conflict';
      case failed:
        return 'Sync failed';
      case offline:
        return 'Offline';
      default:
        return s;
    }
  }
}

class Project {
  const Project({
    required this.id,
    required this.name,
    required this.slug,
    required this.projectType,
    required this.framework,
    required this.localRootPath,
    required this.createdAt,
    required this.updatedAt,
    required this.syncState,
    this.description,
    this.packageId,
    this.versionName,
    this.buildNumber,
    this.logoLocalUri,
    this.repositoryOwner,
    this.repositoryName,
    this.repositoryId,
    this.defaultBranch,
    this.currentBranch,
    this.visibility,
    this.lastLocalEditAt,
    this.lastSyncedAt,
    this.lastSuccessfulBuildAt,
    this.archived = false,
  });

  final String id;
  final String name;
  final String slug;
  final String? description;
  final String projectType; // 'application' | 'repository'
  final ProjectFramework framework;
  final String? packageId;
  final String? versionName;
  final int? buildNumber;
  final String? logoLocalUri;
  final String localRootPath;
  final String? repositoryOwner;
  final String? repositoryName;
  final int? repositoryId;
  final String? defaultBranch;
  final String? currentBranch;
  final String? visibility; // 'public' | 'private' | null (not linked)
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? lastLocalEditAt;
  final DateTime? lastSyncedAt;
  final DateTime? lastSuccessfulBuildAt;
  final String syncState;
  final bool archived;

  bool get isLinked => repositoryName != null;

  /// "Flutter • Public", "Android • Private" or "Web / PWA • Local only".
  String get subtitle {
    final vis = switch (visibility) {
      'public' => 'Public',
      'private' => 'Private',
      _ => 'Local only',
    };
    return '${framework.label} • $vis';
  }

  factory Project.fromMap(Map<String, Object?> m) {
    DateTime? ts(String k) {
      final v = m[k];
      return v is int ? DateTime.fromMillisecondsSinceEpoch(v) : null;
    }

    return Project(
      id: m['id'] as String,
      name: m['name'] as String,
      slug: m['slug'] as String,
      description: m['description'] as String?,
      projectType: m['project_type'] as String,
      framework: ProjectFramework.fromId(m['framework'] as String?),
      packageId: m['package_id'] as String?,
      versionName: m['version_name'] as String?,
      buildNumber: m['build_number'] as int?,
      logoLocalUri: m['logo_local_uri'] as String?,
      localRootPath: m['local_root_path'] as String,
      repositoryOwner: m['repository_owner'] as String?,
      repositoryName: m['repository_name'] as String?,
      repositoryId: m['repository_id'] as int?,
      defaultBranch: m['default_branch'] as String?,
      currentBranch: m['current_branch'] as String?,
      visibility: m['visibility'] as String?,
      createdAt: ts('created_at')!,
      updatedAt: ts('updated_at')!,
      lastLocalEditAt: ts('last_local_edit_at'),
      lastSyncedAt: ts('last_synced_at'),
      lastSuccessfulBuildAt: ts('last_successful_build_at'),
      syncState: (m['sync_state'] as String?) ?? SyncState.localOnly,
      archived: (m['archived'] as int? ?? 0) == 1,
    );
  }
}
