import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/theme/app_colors.dart';
import 'new_local_project_sheet.dart';
import 'project_providers.dart';
import 'project_tile.dart';

/// Basic Projects tab. The full project cards (quick actions, local/remote
/// status, branch, last build) arrive with the project workspace in Part 4.
class ProjectsScreen extends ConsumerWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final k = context.k;
    final projects = ref.watch(allProjectsProvider);

    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('Projects',
                      style: TextStyle(
                          color: k.text,
                          fontSize: 24,
                          fontWeight: FontWeight.w800)),
                ),
                IconButton.filled(
                  tooltip: 'New local project',
                  style: IconButton.styleFrom(
                      backgroundColor: AppColors.purple,
                      foregroundColor: Colors.white),
                  onPressed: () => showNewLocalProjectSheet(context),
                  icon: const Icon(Icons.add_rounded),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: projects.when(
                loading: () => const Center(
                    child: CircularProgressIndicator(color: AppColors.purple)),
                error: (e, _) => Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline_rounded,
                          color: AppColors.danger, size: 36),
                      const SizedBox(height: 8),
                      Text('Could not load projects',
                          style: TextStyle(color: k.text)),
                      TextButton(
                        onPressed: () => ref.invalidate(allProjectsProvider),
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                ),
                data: (list) {
                  if (list.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.folder_open_rounded,
                              size: 44, color: k.muted),
                          const SizedBox(height: 10),
                          Text('No projects yet',
                              style: TextStyle(
                                  color: k.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700)),
                          const SizedBox(height: 6),
                          Text('Tap + to create your first project.',
                              style: TextStyle(color: k.muted)),
                        ],
                      ),
                    );
                  }
                  return RefreshIndicator(
                    color: AppColors.purple,
                    onRefresh: () async {
                      refreshProjectData(ref);
                      await ref.read(allProjectsProvider.future);
                    },
                    child: ListView.separated(
                      padding: const EdgeInsets.only(bottom: 24),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) => ProjectTile(
                        project: list[i],
                        onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text(
                                  'The project workspace is built in Part 4.')),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
