import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';
import '../../shared/time_ago.dart';
import 'project.dart';

/// Recent-project row used on Home and the Projects tab (mockup 2).
class ProjectTile extends StatelessWidget {
  const ProjectTile({super.key, required this.project, this.onTap});

  final Project project;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    final fw = project.framework;
    final needsAttention =
        SyncState.needsAttention.contains(project.syncState);

    return Material(
      color: k.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: k.border),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: fw.color.withAlpha(46),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: fw.color.withAlpha(90)),
                ),
                child: Icon(fw.icon, color: fw.color, size: 26),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      project.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: k.text,
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      project.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: k.muted, fontSize: 12.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'Updated ${timeAgo(project.updatedAt)}',
                    style: TextStyle(color: k.muted, fontSize: 11.5),
                  ),
                  if (needsAttention) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.sync_problem_rounded,
                            size: 13, color: AppColors.gold),
                        const SizedBox(width: 3),
                        Text(SyncState.label(project.syncState),
                            style: const TextStyle(
                                color: AppColors.gold, fontSize: 11)),
                      ],
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
