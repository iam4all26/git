import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/theme/app_colors.dart';
import 'project.dart';
import 'project_providers.dart';
import 'project_repository.dart';

/// Temporary stand-in for the full 7-step wizard (Part 2). It creates a real
/// local-only project with a managed directory so the dashboard shows real
/// data. GitHub linking is added by the wizard.
Future<void> showNewLocalProjectSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _NewLocalProjectSheet(),
  );
}

class _NewLocalProjectSheet extends ConsumerStatefulWidget {
  const _NewLocalProjectSheet();

  @override
  ConsumerState<_NewLocalProjectSheet> createState() =>
      _NewLocalProjectSheetState();
}

class _NewLocalProjectSheetState extends ConsumerState<_NewLocalProjectSheet> {
  final _name = TextEditingController();
  final _desc = TextEditingController();
  ProjectFramework _framework = ProjectFramework.flutter;
  String? _error;
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    setState(() {
      _error = null;
      _saving = true;
    });
    try {
      await ref.read(projectRepositoryProvider).createLocal(
            name: _name.text,
            framework: _framework,
            description: _desc.text,
          );
      if (!mounted) return;
      refreshProjectData(ref);
      final messenger = ScaffoldMessenger.of(context);
      Navigator.of(context).pop();
      messenger.showSnackBar(const SnackBar(
        content: Text('Project created on this device. Not linked to GitHub yet.'),
      ));
    } on ProjectNameException catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error =
          'Could not create the project. Check that your phone has free storage and try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 4, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('New local project',
                style: TextStyle(
                    color: k.text, fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
              'Saved on this phone. You can link or create a GitHub repository later.',
              style: TextStyle(color: k.muted, fontSize: 13),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              textInputAction: TextInputAction.next,
              maxLength: 60,
              decoration: InputDecoration(
                labelText: 'Project name',
                hintText: 'My Awesome App',
                errorText: _error,
                counterText: '',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _desc,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
              ),
            ),
            const SizedBox(height: 14),
            Text('Type',
                style: TextStyle(
                    color: k.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final f in ProjectFramework.values)
                  ChoiceChip(
                    avatar: Icon(f.icon, size: 18, color: f.color),
                    label: Text(f.label),
                    selected: _framework == f,
                    selectedColor: AppColors.purple.withAlpha(70),
                    onSelected: (_) => setState(() => _framework = f),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _saving ? null : _create,
              child: _saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.4, color: Colors.white),
                    )
                  : const Text('Create project'),
            ),
          ],
        ),
      ),
    );
  }
}
