import 'dart:io';
import 'dart:math';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../../core/storage/app_database.dart';
import 'project.dart';

class DashboardStats {
  const DashboardStats({
    required this.projects,
    required this.repositories,
    required this.builds,
    required this.artifacts,
    required this.pendingSync,
  });

  final int projects;
  final int repositories;
  final int builds;
  final int artifacts;

  /// Projects whose local state needs attention (pending, conflict, failed).
  final int pendingSync;
}

class ProjectNameException implements Exception {
  ProjectNameException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// All reads/writes for projects go through here so widgets never touch SQL.
class ProjectRepository {
  ProjectRepository(this._appDb);
  final AppDatabase _appDb;

  Future<List<Project>> listProjects() async {
    final db = await _appDb.database;
    final rows = await db.query(
      'projects',
      where: 'deleted_at IS NULL AND archived = 0',
      orderBy: 'updated_at DESC',
    );
    return rows.map(Project.fromMap).toList();
  }

  Future<DashboardStats> loadStats() async {
    final db = await _appDb.database;
    Future<int> count(String sql, [List<Object?>? args]) async =>
        Sqflite.firstIntValue(await db.rawQuery(sql, args)) ?? 0;

    final states = SyncState.needsAttention.map((_) => '?').join(',');
    return DashboardStats(
      projects: await count(
          'SELECT COUNT(*) FROM projects WHERE deleted_at IS NULL AND archived = 0'),
      repositories: await count('SELECT COUNT(*) FROM repo_cache'),
      builds: await count('SELECT COUNT(*) FROM build_runs'),
      artifacts: await count('SELECT COUNT(*) FROM artifacts'),
      pendingSync: await count(
        'SELECT COUNT(*) FROM projects WHERE deleted_at IS NULL AND archived = 0 '
        'AND sync_state IN ($states)',
        SyncState.needsAttention,
      ),
    );
  }

  /// Creates a local-only project with a managed directory. GitHub linking
  /// happens later (spec 5.4: create first, link/create the remote later).
  Future<Project> createLocal({
    required String name,
    required ProjectFramework framework,
    String? description,
  }) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) {
      throw ProjectNameException('Please enter a project name.');
    }
    if (trimmed.length > 60) {
      throw ProjectNameException('Project name must be 60 characters or fewer.');
    }

    final db = await _appDb.database;
    final slug = await _uniqueSlug(db, slugify(trimmed));
    final id = _newId();
    final docs = await getApplicationDocumentsDirectory();
    final root = Directory(p.join(docs.path, 'projects', id));
    await root.create(recursive: true);

    final now = DateTime.now().millisecondsSinceEpoch;
    try {
      await db.transaction((txn) async {
        await txn.insert('projects', {
          'id': id,
          'name': trimmed,
          'slug': slug,
          'description': (description ?? '').trim().isEmpty
              ? null
              : description!.trim(),
          'project_type': framework == ProjectFramework.repository
              ? 'repository'
              : 'application',
          'framework': framework.id,
          'local_root_path': root.path,
          'created_at': now,
          'updated_at': now,
          'last_local_edit_at': now,
          'sync_state': SyncState.localOnly,
        });
        await txn.insert('project_configs', {'project_id': id});
      });
    } catch (_) {
      // Do not leave an orphan directory if the record could not be saved.
      if (await root.exists()) await root.delete(recursive: true);
      rethrow;
    }

    final rows = await db.query('projects', where: 'id = ?', whereArgs: [id]);
    return Project.fromMap(rows.first);
  }

  static String slugify(String input) {
    var s = input.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-');
    s = s.replaceAll(RegExp(r'^-+|-+$'), '');
    if (s.isEmpty) s = 'project';
    return s.length > 50 ? s.substring(0, 50) : s;
  }

  Future<String> _uniqueSlug(Database db, String base) async {
    var candidate = base;
    var n = 2;
    while (true) {
      final rows = await db.query('projects',
          columns: ['id'],
          where: 'slug = ? AND deleted_at IS NULL',
          whereArgs: [candidate],
          limit: 1);
      if (rows.isEmpty) return candidate;
      candidate = '$base-$n';
      n++;
    }
  }

  String _newId() {
    final rnd = Random.secure().nextInt(0xFFFFFF).toRadixString(36);
    return '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}$rnd';
  }
}
