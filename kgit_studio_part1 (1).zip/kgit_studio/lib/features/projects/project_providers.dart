import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/storage/app_database.dart';
import 'project.dart';
import 'project_repository.dart';

final appDatabaseProvider = Provider<AppDatabase>((ref) => AppDatabase.instance);

final projectRepositoryProvider = Provider<ProjectRepository>(
  (ref) => ProjectRepository(ref.watch(appDatabaseProvider)),
);

final allProjectsProvider = FutureProvider<List<Project>>(
  (ref) => ref.watch(projectRepositoryProvider).listProjects(),
);

final dashboardStatsProvider = FutureProvider<DashboardStats>(
  (ref) => ref.watch(projectRepositoryProvider).loadStats(),
);

/// Which bottom-navigation tab is selected. Home cards switch tabs through it.
final tabIndexProvider = StateProvider<int>((ref) => 0);

/// Theme mode (dark is the flagship experience). Stored in plain preferences;
/// it is not sensitive.
class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier(this._db) : super(ThemeMode.dark);
  final AppDatabase _db;

  Future<void> load() async {
    final saved = await _db.getPref('theme_mode');
    state = switch (saved) {
      'light' => ThemeMode.light,
      'system' => ThemeMode.system,
      _ => ThemeMode.dark,
    };
  }

  Future<void> set(ThemeMode mode) async {
    state = mode;
    await _db.setPref('theme_mode', mode.name);
  }
}

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>(
  (ref) => ThemeModeNotifier(ref.watch(appDatabaseProvider)),
);

/// Call after any change that affects the dashboard or project lists.
void refreshProjectData(WidgetRef ref) {
  ref.invalidate(allProjectsProvider);
  ref.invalidate(dashboardStatsProvider);
}
