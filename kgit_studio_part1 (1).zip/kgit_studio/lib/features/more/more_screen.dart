import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/theme/app_colors.dart';
import '../../features/projects/project_providers.dart';
import '../../shared/widgets/coming_soon_screen.dart';
import '../../shared/widgets/k_logo.dart';

/// "More / Workspace" destination (spec 5.1): Repositories, Settings,
/// appearance and app info.
class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final k = context.k;
    final mode = ref.watch(themeModeProvider);

    void open(String title, IconData icon, String part, List<String> items) {
      Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => ComingSoonScreen(
          title: title,
          icon: icon,
          part: part,
          showBack: true,
          willInclude: items,
        ),
      ));
    }

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        children: [
          Text('More',
              style: TextStyle(
                  color: k.text, fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          _Section(title: 'Workspace', children: [
            _Row(
              icon: Icons.storage_rounded,
              title: 'Repositories',
              subtitle: 'Browse and manage GitHub repositories',
              onTap: () => open('Repositories', Icons.storage_rounded, 'Part 3', [
                'Connect GitHub with a Personal Access Token',
                'Browse, search, filter and refresh repositories',
                'Create repositories; view branches, commits and pull requests',
              ]),
            ),
            _Row(
              icon: Icons.settings_outlined,
              title: 'Settings',
              subtitle: 'GitHub connection, storage, security, diagnostics',
              onTap: () => open('Settings', Icons.settings_outlined, 'Part 3', [
                'GitHub token: test, replace and disconnect',
                'Storage usage and cache cleanup',
                'Sanitized diagnostics you can copy',
              ]),
            ),
          ]),
          const SizedBox(height: 18),
          _Section(title: 'Appearance', children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                child: SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  style: SegmentedButton.styleFrom(
                    selectedBackgroundColor: AppColors.purple,
                    selectedForegroundColor: Colors.white,
                    foregroundColor: k.text,
                    side: BorderSide(color: k.border),
                  ),
                  segments: const [
                    ButtonSegment(
                        value: ThemeMode.dark,
                        icon: Icon(Icons.dark_mode_outlined),
                        label: Text('Dark')),
                    ButtonSegment(
                        value: ThemeMode.light,
                        icon: Icon(Icons.light_mode_outlined),
                        label: Text('Light')),
                    ButtonSegment(
                        value: ThemeMode.system,
                        icon: Icon(Icons.phone_android_rounded),
                        label: Text('System')),
                  ],
                  selected: {mode},
                  onSelectionChanged: (s) =>
                      ref.read(themeModeProvider.notifier).set(s.first),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 18),
          _Section(title: 'About', children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  const KLogo(size: 48, glow: false),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('K-Git Studio',
                            style: TextStyle(
                                color: k.text,
                                fontSize: 16,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 2),
                        Text('Version 0.1.0 • Build, Code, Manage, Deploy',
                            style: TextStyle(color: k.muted, fontSize: 12.5)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ]),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});
  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(title.toUpperCase(),
              style: TextStyle(
                  color: k.muted,
                  fontSize: 11.5,
                  letterSpacing: 1,
                  fontWeight: FontWeight.w700)),
        ),
        Container(
          decoration: BoxDecoration(
            color: k.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: k.border),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: AppColors.purple.withAlpha(40),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: AppColors.purpleSoft),
      ),
      title: Text(title,
          style: TextStyle(color: k.text, fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: TextStyle(color: k.muted, fontSize: 12.5)),
      trailing: Icon(Icons.chevron_right_rounded, color: k.muted),
    );
  }
}
