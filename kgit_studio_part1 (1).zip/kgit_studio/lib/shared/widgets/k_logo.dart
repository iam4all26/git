import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';

/// The K-Git Studio mark: a rounded purple tile with a bold K and a gold
/// "commit" node, used on the splash screen and in headers.
class KLogo extends StatelessWidget {
  const KLogo({super.key, this.size = 56, this.glow = true});

  final double size;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.27),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.purpleSoft, AppColors.purple, AppColors.purpleDeep],
        ),
        border: Border.all(color: Colors.white.withAlpha(46), width: 1.2),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: AppColors.purple.withAlpha(110),
                  blurRadius: size * 0.35,
                  spreadRadius: size * 0.02,
                ),
              ]
            : null,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Text(
            'K',
            style: TextStyle(
              color: Colors.white,
              fontSize: size * 0.62,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          Positioned(
            right: size * 0.17,
            top: size * 0.17,
            child: Container(
              width: size * 0.11,
              height: size * 0.11,
              decoration: const BoxDecoration(
                color: AppColors.gold,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
