import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';

/// Subtle purple glow behind screens in dark mode (plain background in light).
class AppBackdrop extends StatelessWidget {
  const AppBackdrop({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: k.bg,
        gradient: k.isDark
            ? const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF14104A), Color(0xFF080B24), Color(0xFF070A1F)],
                stops: [0, 0.35, 1],
              )
            : null,
      ),
      child: child,
    );
  }
}
