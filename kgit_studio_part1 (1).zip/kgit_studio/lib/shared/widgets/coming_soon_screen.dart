import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';

/// Honest placeholder for screens that belong to a later build part.
/// Nothing here pretends to work (spec 2.1: "Do not pretend an
/// unimplemented button is functional").
class ComingSoonScreen extends StatelessWidget {
  const ComingSoonScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.part,
    required this.willInclude,
    this.showBack = false,
  });

  final String title;
  final IconData icon;
  final String part;
  final List<String> willInclude;
  final bool showBack;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    final body = SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          if (!showBack)
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Text(title,
                  style: TextStyle(
                      color: k.text, fontSize: 24, fontWeight: FontWeight.w800)),
            ),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: k.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: k.border),
            ),
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.purple.withAlpha(40),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(icon, color: AppColors.purpleSoft, size: 32),
                ),
                const SizedBox(height: 16),
                Text('$title is built in $part',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: k.text,
                        fontSize: 17,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text(
                  'This screen is not available yet. It will be added in a later part of the build.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: k.muted, fontSize: 14, height: 1.4),
                ),
                const SizedBox(height: 18),
                for (final item in willInclude)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 2),
                          child: Icon(Icons.check_circle_outline_rounded,
                              size: 16, color: AppColors.purpleSoft),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(item,
                              style: TextStyle(
                                  color: k.text, fontSize: 13.5, height: 1.35)),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );

    if (showBack) {
      return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: body,
      );
    }
    return body;
  }
}
