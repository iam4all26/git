import 'package:flutter/material.dart';

/// Brand anchors from the specification (section 14 / 20.2).
class AppColors {
  AppColors._();

  static const Color purple = Color(0xFF7351FF);
  static const Color purpleDeep = Color(0xFF4A2FD0);
  static const Color purpleSoft = Color(0xFF9D86FF);
  static const Color gold = Color(0xFFF6C101);

  // Semantic colors
  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF59E0B);
  static const Color danger = Color(0xFFEF4444);
  static const Color info = Color(0xFF38BDF8);
}

/// Surface palette that changes between the dark (flagship) and light themes.
class KPalette {
  const KPalette({
    required this.isDark,
    required this.bg,
    required this.surface,
    required this.surfaceHigh,
    required this.border,
    required this.text,
    required this.muted,
  });

  final bool isDark;
  final Color bg;
  final Color surface;
  final Color surfaceHigh;
  final Color border;
  final Color text;
  final Color muted;

  static const KPalette dark = KPalette(
    isDark: true,
    bg: Color(0xFF070A1F),
    surface: Color(0xFF0E1232),
    surfaceHigh: Color(0xFF161B45),
    border: Color(0xFF2B3070),
    text: Color(0xFFF3F4FF),
    muted: Color(0xFF8D93C7),
  );

  static const KPalette light = KPalette(
    isDark: false,
    bg: Color(0xFFF6F6FC),
    surface: Color(0xFFFFFFFF),
    surfaceHigh: Color(0xFFEFEEFB),
    border: Color(0xFFDEDCF2),
    text: Color(0xFF15172E),
    muted: Color(0xFF6A6E92),
  );
}

extension KPaletteContext on BuildContext {
  KPalette get k => Theme.of(this).brightness == Brightness.dark
      ? KPalette.dark
      : KPalette.light;
}
