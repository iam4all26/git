import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/home/home_screen.dart';
import '../../features/more/more_screen.dart';
import '../../features/projects/project_providers.dart';
import '../../features/projects/projects_screen.dart';
import '../../shared/widgets/app_backdrop.dart';
import '../../shared/widgets/coming_soon_screen.dart';
import '../theme/app_colors.dart';

class _Dest {
  const _Dest(this.label, this.icon, this.activeIcon);
  final String label;
  final IconData icon;
  final IconData activeIcon;
}

const _destinations = [
  _Dest('Home', Icons.home_outlined, Icons.home_rounded),
  _Dest('Projects', Icons.folder_open_outlined, Icons.folder_rounded),
  _Dest('Builds', Icons.construction_outlined, Icons.construction_rounded),
  _Dest('Artifacts', Icons.inventory_2_outlined, Icons.inventory_2_rounded),
  _Dest('More', Icons.menu_rounded, Icons.menu_rounded),
];

/// Bottom navigation shell (spec 5.1): Home, Projects, Builds, Artifacts and
/// More. Repositories and Settings live under More.
class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = ref.watch(tabIndexProvider);

    return Scaffold(
      body: AppBackdrop(
        child: IndexedStack(
          index: index,
          children: const [
            HomeScreen(),
            ProjectsScreen(),
            ComingSoonScreen(
              title: 'Build Center',
              icon: Icons.construction_rounded,
              part: 'Part 6',
              willInclude: [
                'Workflow runs across all projects with status, branch and commit',
                'Dispatch builds for APK, AAB or both',
                'Logs, copy sanitized error details, rerun and cancel',
              ],
            ),
            ComingSoonScreen(
              title: 'Artifacts',
              icon: Icons.inventory_2_outlined,
              part: 'Part 7',
              willInclude: [
                'APK, AAB and ZIP library with search, filter and sort',
                'Download manager with verified, offline-ready files',
                'Install APK through Android, share and delete local copies',
              ],
            ),
            MoreScreen(),
          ],
        ),
      ),
      bottomNavigationBar: _BottomBar(
        index: index,
        onSelected: (i) => ref.read(tabIndexProvider.notifier).state = i,
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({required this.index, required this.onSelected});
  final int index;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    return Container(
      decoration: BoxDecoration(
        color: k.surface,
        border: Border(top: BorderSide(color: k.border)),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              for (var i = 0; i < _destinations.length; i++)
                Expanded(
                  child: _NavItem(
                    dest: _destinations[i],
                    selected: i == index,
                    onTap: () => onSelected(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.dest,
    required this.selected,
    required this.onTap,
  });
  final _Dest dest;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final k = context.k;
    final color = selected ? AppColors.purpleSoft : k.muted;
    return Semantics(
      button: true,
      selected: selected,
      label: dest.label,
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46,
              height: 28,
              decoration: BoxDecoration(
                color: selected
                    ? AppColors.purple.withAlpha(60)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(selected ? dest.activeIcon : dest.icon,
                  color: color, size: 23),
            ),
            const SizedBox(height: 3),
            Text(dest.label,
                style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}
