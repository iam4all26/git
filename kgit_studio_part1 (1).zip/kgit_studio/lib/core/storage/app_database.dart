import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Local SQLite index/cache (spec section 9). It is NOT a remote database:
/// source file bytes live in the managed project directory, and secrets
/// (PATs, signing material) must never be stored here.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  static const int schemaVersion = 1;
  static const String fileName = 'k_git_studio.db';

  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, fileName),
      version: schemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        for (var v = 1; v <= version; v++) {
          await _migrations[v]!(db);
        }
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        for (var v = oldVersion + 1; v <= newVersion; v++) {
          await _migrations[v]!(db);
        }
      },
    );
  }

  /// One entry per schema version. Add `2: (db) async {...}` for future
  /// changes; existing installs are upgraded step by step.
  static final Map<int, Future<void> Function(Database db)> _migrations = {
    1: _v1,
  };

  static Future<void> _v1(Database db) async {
    await db.execute('''
      CREATE TABLE projects (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT NOT NULL,
        description TEXT,
        project_type TEXT NOT NULL,
        framework TEXT NOT NULL,
        package_id TEXT,
        version_name TEXT,
        build_number INTEGER,
        logo_local_uri TEXT,
        local_root_path TEXT NOT NULL,
        repository_owner TEXT,
        repository_name TEXT,
        repository_id INTEGER,
        default_branch TEXT,
        current_branch TEXT,
        visibility TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        last_local_edit_at INTEGER,
        last_synced_at INTEGER,
        last_successful_build_at INTEGER,
        sync_state TEXT NOT NULL DEFAULT 'local_only',
        archived INTEGER NOT NULL DEFAULT 0,
        deleted_at INTEGER
      )
    ''');
    await db.execute(
        'CREATE UNIQUE INDEX idx_projects_slug ON projects(slug) WHERE deleted_at IS NULL');
    await db.execute('CREATE INDEX idx_projects_updated ON projects(updated_at)');

    await db.execute('''
      CREATE TABLE project_configs (
        project_id TEXT PRIMARY KEY,
        build_profile_id TEXT,
        workflow_file TEXT,
        target_options TEXT,
        framework_options TEXT,
        environment_variable_names TEXT,
        secret_reference_names TEXT,
        config_version INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE local_files (
        project_id TEXT NOT NULL,
        relative_path TEXT NOT NULL,
        file_type TEXT,
        size_bytes INTEGER,
        modified_at INTEGER,
        checksum TEXT,
        sync_state TEXT NOT NULL DEFAULT 'local_only',
        PRIMARY KEY (project_id, relative_path),
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE repo_cache (
        id INTEGER PRIMARY KEY,
        owner TEXT NOT NULL,
        name TEXT NOT NULL,
        full_name TEXT NOT NULL,
        description TEXT,
        language TEXT,
        visibility TEXT,
        default_branch TEXT,
        archived INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER,
        cached_at INTEGER NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE build_runs (
        id TEXT PRIMARY KEY,
        project_id TEXT,
        repository_id INTEGER,
        workflow_id INTEGER,
        workflow_name TEXT,
        run_id INTEGER,
        branch TEXT,
        commit_sha TEXT,
        target TEXT,
        status TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        duration_seconds INTEGER,
        html_url TEXT,
        last_error_summary TEXT
      )
    ''');
    await db.execute('CREATE INDEX idx_build_runs_created ON build_runs(created_at)');

    await db.execute('''
      CREATE TABLE artifacts (
        id TEXT PRIMARY KEY,
        project_id TEXT,
        build_run_id TEXT,
        remote_artifact_id INTEGER,
        name TEXT NOT NULL,
        artifact_type TEXT NOT NULL,
        remote_url TEXT,
        local_path TEXT,
        size_bytes INTEGER,
        version_label TEXT,
        created_at INTEGER NOT NULL,
        downloaded_at INTEGER,
        expires_at INTEGER,
        checksum TEXT,
        availability_state TEXT NOT NULL DEFAULT 'remote_only'
      )
    ''');

    await db.execute('''
      CREATE TABLE import_export_ops (
        id TEXT PRIMARY KEY,
        project_id TEXT,
        operation_type TEXT NOT NULL,
        source_name TEXT,
        started_at INTEGER NOT NULL,
        completed_at INTEGER,
        status TEXT NOT NULL,
        summary TEXT,
        warnings TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE preferences (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');
  }

  // ---- Preferences (non-sensitive only) --------------------------------

  Future<String?> getPref(String key) async {
    final db = await database;
    final rows = await db.query('preferences',
        where: 'key = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first['value'] as String?;
  }

  Future<void> setPref(String key, String value) async {
    final db = await database;
    await db.insert('preferences', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
