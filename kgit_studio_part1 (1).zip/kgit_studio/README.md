# K-Git Studio

Build • Code • Manage • Deploy. A native Flutter workspace for managing GitHub projects, editing code, building in the cloud and keeping APK/AAB files, all from an Android phone.

## Build progress

| Part | Content | Status |
|------|---------|--------|
| 1 | Project setup, CI, theme, local database, Splash, navigation, Home dashboard | Written (not yet built or run) |
| 2 | Project creation wizard (7 steps, mockups 3-6) | Next |
| 3 | GitHub PAT connection, Repositories, Settings | Planned |
| 4 | Project workspace, file explorer, code editor (mockups 7-8) | Planned |
| 5 | Git changes and commit (mockup 9) | Planned |
| 6 | Build Center and build log (mockups 10-11) | Planned |
| 7 | Artifacts library, downloads, APK install (mockup 12) | Planned |
| 8 | ZIP import/export, AI Context prompt, release signing | Planned |

## How to build the APK (no Flutter needed on your phone)

1. Create a GitHub repository (for example `k-git-studio`).
2. Upload everything in this folder to it, including the hidden `.github` folder.
3. Open the repository, go to **Actions**, choose **Build K-Git Studio APK** and tap **Run workflow**.
4. When it finishes, open the run, scroll to **Artifacts** and download `k-git-studio-apk`.
5. Unzip it and install `app-release.apk` (allow "install unknown apps" for your file manager or browser).

The workflow creates the Android host project automatically, so only Dart code and config are stored in the repository.

If the build fails, open the failed step in the run, copy the error text and send it back.

## Notes

- No PHP, MySQL, Termux or custom server is used.
- Data is stored on the phone (SQLite). Tokens will be kept in Android secure storage (Part 3), never in the database.
- The release APK is signed with the default debug key until signing is set up in a later part.
