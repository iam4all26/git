import 'package:flutter_test/flutter_test.dart';
import 'package:k_git_studio/features/projects/project_repository.dart';
import 'package:k_git_studio/shared/time_ago.dart';

void main() {
  group('slugify', () {
    test('lowercases and replaces symbols', () {
      expect(ProjectRepository.slugify('My Awesome App!'), 'my-awesome-app');
    });
    test('falls back when nothing usable remains', () {
      expect(ProjectRepository.slugify('!!!'), 'project');
    });
  });

  group('timeAgo', () {
    final now = DateTime(2026, 10, 29, 12);
    test('minutes', () {
      expect(timeAgo(now.subtract(const Duration(minutes: 5)), now: now),
          '5m ago');
    });
    test('hours', () {
      expect(timeAgo(now.subtract(const Duration(hours: 2)), now: now),
          '2h ago');
    });
    test('days', () {
      expect(timeAgo(now.subtract(const Duration(days: 3)), now: now),
          '3d ago');
    });
  });
}
